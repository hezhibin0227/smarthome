#!/usr/bin/python
# -*- coding: UTF-8 -*-

env_redis_host = 'redis-13341.c8.us-east-1-3.ec2.cloud.redislabs.com'  # redisStore.py
env_redis_port = '13341'  # redisStore.py
env_redis_password = '3vFdwO9Dbu2AXJre'  # redisStore.py








